from __future__ import annotations

import html
import re
from datetime import datetime
from pathlib import Path
from urllib.parse import quote_plus

SUBJECT = "Courtesy Bus Pickup Location"
IMAGE_EXTS = {".jpeg", ".jpg", ".png", ".webp"}


def _candidate_static_dirs() -> list[Path]:
    here = Path(__file__).resolve()
    candidates = [
        Path("/home/ubuntu/opsly/app/static"),
        Path("/home/ubuntu/app/static"),
        here.parents[1] / "static",
        here.parents[2] / "app" / "static",
        here.parents[2] / "static",
    ]
    seen: list[Path] = []
    for path in candidates:
        try:
            resolved = path.resolve()
        except Exception:
            resolved = path
        if resolved not in seen:
            seen.append(resolved)
    return seen


def _existing_file(filename: str | None) -> Path | None:
    if not filename:
        return None
    for base in _candidate_static_dirs():
        path = base / filename
        if path.exists() and path.is_file():
            return path
    return None


def _iter_images() -> list[Path]:
    found: list[Path] = []
    seen = set()
    for base in _candidate_static_dirs():
        if not base.exists() or not base.is_dir():
            continue
        for path in sorted(base.iterdir()):
            if not path.is_file() or path.suffix.lower() not in IMAGE_EXTS:
                continue
            resolved = path.resolve()
            if resolved not in seen:
                seen.add(resolved)
                found.append(path)
    return found


def _slug(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value or "").lower())


def _map_link(address: str) -> str:
    clean = str(address or "").strip()
    if not clean:
        return "#"
    return f"https://www.google.com/maps/search/?api=1&query={quote_plus(clean)}"


def _friendly_date(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return "your flight date"
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(text[:19], fmt).strftime("%-d %B %Y")
        except Exception:
            pass
    return text


def _value(order, *keys, default=""):
    for key in keys:
        value = order.get(key)
        if value not in (None, ""):
            return value
    return default


def _name(order):
    return _value(order, "customer_name", default="Customer")


def _order_number(order):
    return _value(order, "order_number", default="-")


def _flight_date(order):
    return _friendly_date(_value(order, "travel_date", "flight_date", "pickup_date", default=""))


def _pickup_time(order, *, meeting=False):
    if meeting:
        return _value(order, "meeting_time", "pickup_time", default="TBC")
    return _value(order, "pickup_time", "meeting_time", default="TBC")


def _pickup_label(order):
    return _value(order, "pickup_location", "pickup", default="")


def _build_body(order, config):
    customer = html.escape(str(_name(order)))
    date_text = html.escape(str(_flight_date(order)))
    reservation = html.escape(str(_order_number(order)))
    address_text = str(config["address"])
    address = html.escape(address_text)
    map_link = _map_link(address_text)
    when_value = html.escape(str(_pickup_time(order, meeting=config.get("meeting", False))))
    intro_label = "meeting location" if config.get("meeting") else "courtesy pickup location"
    picture_line = config.get("picture_line") or "Please see picture of your pickup location and vehicle attached."
    confirm_line = config.get("confirm_line") or 'Please reply "YES" to confirm you have received the pick up location and time.'
    extra_line = config.get("extra_line") or ""

    return f"""
    <div>Hi {customer}</div>
    <br>
    <div>Your {intro_label} on {date_text} is <a href=\"{map_link}\">{address}</a> at {when_value}, touch the address for map and directions.</div>
    <br>
    <div>{html.escape(picture_line)}</div>
    <br>
    <div>{html.escape(config['important'])}</div>
    <br>
    <div>Your reservation number is {reservation}</div>
    {f'<br><div>{html.escape(extra_line)}</div>' if extra_line else ''}
    <br>
    <div>{html.escape(confirm_line)}</div>
    <br>
    <div>Kind regards,</div>
    <div>Whitsunday Air Tours</div>
    """


PICKUPS = [
    {
        "key": "poa",
        "aliases": ["poa", "port of airlie", "portofairlie", "portairlie"],
        "address": "Transit Terminal, 14 The Cv Rd, Airlie Beach",
        "pickup_image": "poa.jpeg",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "thehostel",
        "aliases": ["the hostel", "thehostel", "hostel"],
        "address": "394 Shute Harbour Rd, Airlie Beach",
        "pickup_image": "hostel.jpeg",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "azure",
        "aliases": ["azure"],
        "address": "26 Raintree Place, Airlie Beach",
        "pickup_image": "azure.jpeg",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "mantra",
        "aliases": ["mantra", "mantra club croc", "club croc"],
        "address": "240 Shute Harbour Rd, Cannonvale",
        "pickup_image": "mantra.jpeg",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "tasman",
        "aliases": ["tasman", "tasman holiday parks", "tasman holiday park", "tasmanholidayparks", "tasmanholidaypark"],
        "address": "1 Jubilee Pocket Rd, Airlie Beach",
        "pickup_image": "tasman.jpeg",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "kipara",
        "aliases": ["kipara"],
        "address": "2614 Shute Harbour Rd, Jubilee Pocket",
        "pickup_image": "Kipara.jpeg",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "hermitage",
        "aliases": ["hermitage", "hermitage drive", "hermitage drive bus stop"],
        "address": "Hermitage Drive Bus Stop, Airlie Beach",
        "pickup_image": "hermitage.jpeg",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "islanddrive",
        "aliases": ["island drive", "island drive bus stop", "islanddrive", "island"],
        "address": "Island Drive Bus Stop, Cannonvale",
        "pickup_image": "island.jpeg",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "reefgateway",
        "aliases": ["reef gateway", "reefgateway", "reef"],
        "address": "38 Shute Harbour Rd, Cannonvale",
        "pickup_image": "reef.jpeg",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "marinashores",
        "aliases": ["marina shores", "marinashores", "marina"],
        "address": "159 Shingley Dr, Cannonvale",
        "pickup_image": "marina.jpeg",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "reflections",
        "aliases": ["reflections"],
        "address": "25 Horizons way, Airlie Beach",
        "pickup_image": None,
        "picture_line": "Please see picture of your pickup vehicle attached.",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "coralsearesort",
        "aliases": ["coral sea resort", "coral sea", "csr", "coral"],
        "address": "26 Ocean View Ave, Airlie Beach",
        "pickup_image": "csr.jpeg",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "mirage",
        "aliases": ["mirage"],
        "address": "38 Altmann Ave, Cannonvale",
        "pickup_image": "mirage.jpeg",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "domestic",
        "aliases": ["domestic", "domestic terminal", "airport", "whitsunday coast airport"],
        "address": "Whitsunday Coast Airport",
        "pickup_image": "domestic.jpeg",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "base",
        "aliases": ["base", "nomads", "base/nomads", "nomads/base", "nomads base", "base nomads"],
        "address": "336 Shute Harbour Rd, Airlie Beach",
        "pickup_image": "base.jpeg",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "mow",
        "aliases": ["mow", "laguna quays", "lagunaquays", "lq", "laguana quays"],
        "address": "SKYONE Laguna Quays Airport, 253 Kunapipi Rd, Laguna Quays QLD 4800",
        "pickup_images": ["lqwait.jpeg", "lqpark.jpeg", "lqenter.jpeg"],
        "meeting": True,
        "picture_line": "Please see picture of your meeting location attached.",
        "important": "IMPORTANT!!! - Please be waiting at your meeting location 5 minutes prior to the above mentioned time, the aircraft is unable to wait past your nominated meeting time. The aircraft may occasionally be late, you will be notified of delays longer than 10 minutes.",
        "extra_line": "Alternatively if you would like a courtesy pickup in Airlie Beach or Cannonvale please let us know.",
    },
]


def _first_existing_by_keywords(*keywords: str) -> Path | None:
    words = [_slug(k) for k in keywords if _slug(k)]
    if not words:
        return None
    for path in _iter_images():
        name_slug = _slug(path.stem)
        if any(word and word in name_slug for word in words):
            return path
    return None


def _resolve_images(config, pickup_text: str) -> list[str]:
    images: list[str] = []
    if config.get("key") != "mow":
        bus = _existing_file("bus.jpeg") or _first_existing_by_keywords("bus")
        if bus:
            images.append(str(bus))

    for filename in config.get("pickup_images", []):
        path = _existing_file(filename) or _first_existing_by_keywords(filename)
        if path:
            images.append(str(path))

    pickup_image = config.get("pickup_image")
    if pickup_image:
        path = _existing_file(pickup_image) or _first_existing_by_keywords(
            pickup_image,
            config.get("key", ""),
            pickup_text,
            *config.get("aliases", []),
        )
        if path:
            images.append(str(path))
    elif not config.get("pickup_images"):
        fuzzy = _first_existing_by_keywords(config.get("key", ""), pickup_text, *config.get("aliases", []))
        if fuzzy:
            images.append(str(fuzzy))

    deduped: list[str] = []
    seen = set()
    for item in images:
        p = Path(item)
        if item and item not in seen and p.exists() and p.is_file():
            deduped.append(item)
            seen.add(item)
    return deduped


def resolve_pickup_config(order):
    raw_pickup = _pickup_label(order)
    pickup_text = _slug(raw_pickup)
    best = None
    best_score = 0
    for config in PICKUPS:
        for alias in config.get("aliases", []):
            alias_slug = _slug(alias)
            if not alias_slug:
                continue
            score = 0
            if alias_slug == pickup_text:
                score = 1000 + len(alias_slug)
            elif alias_slug in pickup_text:
                score = 500 + len(alias_slug)
            elif pickup_text and pickup_text in alias_slug:
                score = 100 + len(pickup_text)
            if score > best_score:
                best = config
                best_score = score
    if best:
        return best
    return {
        "key": "generic",
        "aliases": [],
        "address": _value(order, "pickup_address", "pickup_location", default="Pickup location to be confirmed"),
        "pickup_image": None,
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    }


def build_pickup_email(order):
    config = resolve_pickup_config(order)
    pickup_text = _pickup_label(order)
    return {
        "subject": SUBJECT,
        "body": _build_body(order, config),
        "attachments": _resolve_images(config, pickup_text),
        "pickup_key": config.get("key", "generic"),
    }

/*
Keep existing theme. This file is only here as a placeholder if you want to
add client-side helpers for expanding/collapsing all flights later.
*/

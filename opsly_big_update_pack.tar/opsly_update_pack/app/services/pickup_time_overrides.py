from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional

TIME_FORMATS = ("%H:%M", "%I:%M %p", "%H%M")


def _parse_time(value: str) -> Optional[datetime]:
    value = (value or "").strip()
    if not value:
        return None
    for fmt in TIME_FORMATS:
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None


def apply_pickup_override(flight_code: str, rezdy_pickup_time: str) -> str:
    """
    Business rules requested by Ed:
    - 0830 flights => 10 minutes earlier than Rezdy
    - 1430 flights => 20 minutes later than Rezdy
    - everything else unchanged
    """
    dt = _parse_time(rezdy_pickup_time)
    if not dt:
        return rezdy_pickup_time

    normalized = str(flight_code).replace(":", "").strip()
    if normalized == "0830":
        dt -= timedelta(minutes=10)
    elif normalized == "1430":
        dt += timedelta(minutes=20)

    return dt.strftime("%-H:%M")

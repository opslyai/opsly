from __future__ import annotations

from typing import Dict


def build_cancellation_email(order: Dict, reason: str = "general") -> Dict[str, str]:
    customer_name = (
        order.get("customer_name")
        or order.get("name")
        or order.get("lead_name")
        or "Customer"
    )
    reference = (
        order.get("order_number")
        or order.get("reference")
        or order.get("rezdy_order_number")
        or order.get("order_no")
        or "TBC"
    )

    if reason == "weather":
        subject = "Your flight has been cancelled due to weather"
        body = f"""Hi {customer_name},

Unfortunately your flight has been cancelled due to weather conditions.

The safety of our passengers is always our top priority and today's conditions are not suitable for safe operation.

Please reply to this email if you would prefer to reschedule or receive a refund.

Your reference number is: {reference}

Kind regards,
Whitsunday Air Tours"""
    else:
        subject = "Your flight has been cancelled"
        body = f"""Hi {customer_name},

Unfortunately your flight has been cancelled.

We apologise for the inconvenience. Please reply to this email if you would prefer to reschedule or receive a refund.

Your reference number is: {reference}

Kind regards,
Whitsunday Air Tours"""

    return {"subject": subject, "body": body}

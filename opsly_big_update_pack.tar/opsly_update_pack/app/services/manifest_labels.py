from __future__ import annotations

SHORT_PICKUP_LABELS = {
    "Nomads/Base Backpackers": "Base",
    "Base Backpackers": "Base",
    "Nomads": "Base",
    "Tasman Holiday Park": "Tasman",
    "Tasman Holiday Parks": "Tasman",
    "Mantra Club Croc": "Mantra",
    "The Hostel": "Hostel",
    "Own Transport - Meet at SKYONE Laguna Quays Airport": "MOW",
}


def shorten_pickup_label(label: str) -> str:
    label = (label or "").strip()
    if not label:
        return label
    return SHORT_PICKUP_LABELS.get(label, label)

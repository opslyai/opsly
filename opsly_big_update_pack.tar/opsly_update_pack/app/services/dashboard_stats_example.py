from __future__ import annotations

from dataclasses import dataclass

MAX_DAILY_CAPACITY = 35


@dataclass
class DashboardStats:
    today_pax: int = 0
    today_cancelled_pax: int = 0
    today_flights: int = 0
    today_pickups: int = 0
    tomorrow_pax: int = 0
    next_7_days_pax: int = 0
    last_7_days_pax: int = 0

    @property
    def today_remaining_seats(self) -> int:
        return max(MAX_DAILY_CAPACITY - self.today_pax, 0)

    @property
    def today_load_pct(self) -> int:
        if MAX_DAILY_CAPACITY <= 0:
            return 0
        return round((self.today_pax / MAX_DAILY_CAPACITY) * 100)

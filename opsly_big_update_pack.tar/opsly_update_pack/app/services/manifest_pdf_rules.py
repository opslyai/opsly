from __future__ import annotations

from app.services.manifest_labels import shorten_pickup_label


def build_manifest_header(display_date: str) -> list[str]:
    return [
        "Opsly daily manifest",
        display_date,
        "",
        "Pilot summary",
    ]


def normalize_pickup_row(label: str) -> str:
    return shorten_pickup_label(label)

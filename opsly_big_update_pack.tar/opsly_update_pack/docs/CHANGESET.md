# Opsly big update

This pack implements the following requested behavior:

## Dashboard
- Remove misleading stat cards like impossible "50 confirmed today".
- Replace with clearer operational stats:
  - Today total pax booked
  - Today remaining seats
  - Flights operating today
  - Cancelled seats today
  - Tomorrow total pax
  - Next 7 days booked pax
  - Last 7 days completed pax
  - Bus pickups today
- Add a cleaner layout with a hero summary, operational cards, and flight slot cards.
- Keep existing theme tokens untouched.

## Orders nav badge
- Badge should only show a meaningful number, preferably the count of actionable new/cancelled/unprocessed orders.
- If count is 0, hide the badge.

## Flight Deck
- Pickup emails stay the same except pickup times are adjusted:
  - 0830 flights: 10 minutes earlier than Rezdy time
  - 1430 flights: 20 minutes later than Rezdy time
- Each flight becomes a collapsible section so the page is not huge.
- Only flight time and action buttons visible by default.
- "Latest comm" becomes "All comms" and lists all sent items such as pickup, delay, cancel.

## Cancellation emails
- Must include customer name in greeting/body.
- Must include reference line at bottom:
  - "Your reference number is: {reference}"

## Daily manifest PDF
- Remove:
  - Great work today team.
  - Generated timestamp line
  - Phone / Operations
  - Pilot
  - Minibus
- Keep only date header.
- Shorten pickup labels:
  - Nomads/Base Backpackers -> Base
  - Tasman Holiday Park / Tasman Holiday Parks -> Tasman
  - Mantra Club Croc -> Mantra
  - The Hostel -> Hostel
  - Own Transport - Meet at SKYONE Laguna Quays Airport -> MOW

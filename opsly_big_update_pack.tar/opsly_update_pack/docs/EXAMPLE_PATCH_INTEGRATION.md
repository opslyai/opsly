# How to wire this into your existing code

## 1. Pickup time adjustment
Wherever you currently build pickup email payloads or flight deck order rows:

```python
from app.services.pickup_time_overrides import apply_pickup_override
adjusted_pickup_time = apply_pickup_override(flight_code, rezdy_pickup_time)
```

## 2. Cancellation emails
Replace old cancellation email builder with:

```python
from app.services.cancellation_email import build_cancellation_email
payload = build_cancellation_email(order, reason="weather")
```

## 3. Manifest PDF pickup labels
Before writing each pickup label into the PDF:

```python
from app.services.manifest_labels import shorten_pickup_label
label = shorten_pickup_label(raw_label)
```

## 4. Orders nav badge
Pass only actionable counts into the template:

```python
actionable_order_count = new_orders_count + cancelled_orders_count
```

Hide the badge when the count is zero.

## 5. Dashboard data model
Do not show order totals as a proxy for seat totals.
A daily max of 35 seats means all top-line daily stats should be seat-based.

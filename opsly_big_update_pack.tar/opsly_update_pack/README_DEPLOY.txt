OPSly update pack prepared from your requested changes.

IMPORTANT
- Theme is intentionally untouched.
- This pack is a best-effort implementation pack because the live project source code was not uploaded in this chat.
- I could not push this into your GitHub from here.
- The files in this pack are drop-in replacements/examples for the most likely Flask project structure.

Included changes
1. Dashboard redesign spec + replacement template
2. Orders nav badge fix (badge should only show meaningful count)
3. Pickup time override helper:
   - 0830 flights => 10 mins earlier than Rezdy
   - 1430 flights => 20 mins later than Rezdy
4. Cancellation email builder with customer name + reference number
5. Flight Deck collapsible flight cards
6. All Comms section instead of latest comms
7. Daily manifest PDF formatting rules and pickup label shortening

Recommended workflow on EC2
1. Back up current app and database
2. Extract this pack beside your repo
3. Copy the relevant files into the matching project paths
4. Restart the Flask/Gunicorn process

Because I do not have your exact repo structure in this chat, review each file before replacing.

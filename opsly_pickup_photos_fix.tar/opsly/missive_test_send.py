import os, json, base64
from pathlib import Path

import requests
from dotenv import load_dotenv

load_dotenv("/home/ubuntu/opsly/.env")

MISSIVE_PAT = os.getenv("MISSIVE_PAT")
MISSIVE_API_BASE = os.getenv("MISSIVE_API_BASE", "https://public.missiveapp.com/v1").rstrip("/")
MISSIVE_FROM_ADDRESS = os.getenv("MISSIVE_FROM_ADDRESS")

print("MISSIVE_API_BASE =", MISSIVE_API_BASE)
print("MISSIVE_FROM_ADDRESS =", MISSIVE_FROM_ADDRESS)
print("MISSIVE_PAT present =", bool(MISSIVE_PAT))

if not MISSIVE_PAT:
    raise SystemExit("MISSIVE_PAT missing in .env")
if not MISSIVE_FROM_ADDRESS:
    raise SystemExit("MISSIVE_FROM_ADDRESS missing in .env")

roots = [
    Path("/home/ubuntu/opsly/app/static"),
    Path("/home/ubuntu/opsly/static"),
    Path("/home/ubuntu/opsly/app"),
    Path("/home/ubuntu/opsly"),
]

def find_img(words):
    exts = {".png", ".jpg", ".jpeg", ".webp"}
    for root in roots:
        if not root.exists():
            continue
        for p in root.rglob("*"):
            if p.is_file() and p.suffix.lower() in exts:
                n = p.name.lower()
                if any(w in n for w in words):
                    return p
    return None

bus_img = find_img(["bus", "courtesy"])
base_img = find_img(["base", "office", "hangar"])

print("bus_img =", bus_img)
print("base_img =", base_img)

if not bus_img or not base_img:
    raise SystemExit("Could not find bus/base images automatically")

def b64(path):
    return base64.b64encode(path.read_bytes()).decode("ascii")

payload = {
    "drafts": {
        "send": True,
        "subject": "Missive test email",
        "body": (
            "<div>Hello</div><br>"
            "<div>Bus:</div>"
            '<img data-missive-attachment-id="bus-img"><br><br>'
            "<div>Base:</div>"
            '<img data-missive-attachment-id="base-img">'
        ),
        "to_fields": [{"address": "edsaleh98@gmail.com", "name": "Ed Saleh"}],
        "from_field": {"address": MISSIVE_FROM_ADDRESS},
        "attachments": [
            {
                "id": "bus-img",
                "filename": bus_img.name,
                "base64_data": b64(bus_img),
            },
            {
                "id": "base-img",
                "filename": base_img.name,
                "base64_data": b64(base_img),
            },
        ],
    }
}

resp = requests.post(
    f"{MISSIVE_API_BASE}/drafts",
    headers={
        "Authorization": f"Bearer {MISSIVE_PAT}",
        "Content-Type": "application/json",
    },
    json=payload,
    timeout=60,
)

print("STATUS =", resp.status_code)
print(resp.text)
resp.raise_for_status()
print("DONE")

from __future__ import annotations

import html
import re
from datetime import datetime
from pathlib import Path
from urllib.parse import quote_plus

SUBJECT = "Courtesy Bus Pickup Location"
BUS_IMAGE = "/home/ubuntu/opsly/app/static/bus.jpeg"


def _slug(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value or "").lower())


def _map_link(address: str) -> str:
    clean = str(address or "").strip()
    if not clean:
        return "#"
    return f"https://www.google.com/maps/search/?api=1&query={quote_plus(clean)}"


def _friendly_date(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return "your flight date"
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(text[:19], fmt).strftime("%-d %B %Y")
        except Exception:
            pass
    return text


def _value(order, *keys, default=""):
    for key in keys:
        value = order.get(key)
        if value not in (None, ""):
            return value
    return default


def _name(order):
    return _value(order, "customer_name", default="Customer")


def _order_number(order):
    return _value(order, "order_number", default="-")


def _flight_date(order):
    return _friendly_date(_value(order, "travel_date", "flight_date", "pickup_date", default=""))


def _pickup_time(order, *, meeting=False):
    if meeting:
        return _value(order, "meeting_time", "pickup_time", default="TBC")
    return _value(order, "pickup_time", "meeting_time", default="TBC")


def _pickup_label(order):
    return _value(order, "pickup_location", "pickup", default="")


def _build_body(order, config):
    customer = html.escape(str(_name(order)))
    date_text = html.escape(str(_flight_date(order)))
    reservation = html.escape(str(_order_number(order)))
    address = html.escape(config["address"])
    map_link = _map_link(config["address"])
    when_value = html.escape(str(_pickup_time(order, meeting=config.get("meeting", False))))
    intro_label = "meeting location" if config.get("meeting") else "courtesy pickup location"
    vehicle_label = "aircraft" if config.get("meeting") else "bus"
    picture_line = config.get("picture_line") or "Please see picture of your pickup location and vehicle attached."
    confirm_line = config.get("confirm_line") or 'Please reply "YES" to confirm you have received the pick up location and time.'
    extra_line = config.get("extra_line") or ""

    return f"""
    <div>Hi {customer}</div>
    <br>
    <div>Your {intro_label} on {date_text} is <a href="{map_link}">{address}</a> at {when_value}, touch the address for map and directions.</div>
    <br>
    <div>{html.escape(picture_line)}</div>
    <br>
    <div>{html.escape(config['important'])}</div>
    <br>
    <div>Your reservation number is {reservation}</div>
    {f'<br><div>{html.escape(extra_line)}</div>' if extra_line else ''}
    <br>
    <div>{html.escape(confirm_line)}</div>
    <br>
    <div>Kind regards,</div>
    <div>Whitsunday Air Tours</div>
    """


PICKUPS = [
    {
        "key": "poa",
        "aliases": ["poa", "portofairlie", "portairlie", "portofairly"],
        "address": "Transit Terminal, 14 The Cove Road, Airlie Beach",
        "images": [BUS_IMAGE, "/home/ubuntu/opsly/app/static/poa.jpeg"],
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "thehostel",
        "aliases": ["thehostel", "hostel"],
        "address": "394 Shute Harbour Rd, Airlie Beach",
        "images": [BUS_IMAGE, "/home/ubuntu/opsly/app/static/hostel.jpeg"],
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "azure",
        "aliases": ["azure"],
        "address": "26 Raintree Place, Airlie Beach",
        "images": [BUS_IMAGE, "/home/ubuntu/opsly/app/static/azure.jpeg"],
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "mantra",
        "aliases": ["mantra"],
        "address": "240 Shute Harbour Rd, Cannonvale",
        "images": [BUS_IMAGE, "/home/ubuntu/opsly/app/static/mantra.jpeg"],
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "tasman",
        "aliases": ["tasman", "tasmanholidayparks", "tasmanholidaypark", "tasmanpark"],
        "address": "1 Jubilee Pocket Rd, Airlie Beach",
        "images": [BUS_IMAGE, "/home/ubuntu/opsly/app/static/tasman.jpeg"],
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "kipara",
        "aliases": ["kipara"],
        "address": "2614 Shute Harbour Rd, Jubilee Pocket",
        "images": [BUS_IMAGE, "/home/ubuntu/opsly/app/static/Kipara.jpeg"],
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "hermitage",
        "aliases": ["hermitage", "hermitagedrive", "hermitagedrivebusstop"],
        "address": "Hermitage Drive Bus Stop, Airlie Beach",
        "images": [BUS_IMAGE, "/home/ubuntu/opsly/app/static/hermitage.jpeg"],
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "islanddrive",
        "aliases": ["islanddrive", "island"],
        "address": "Island Drive Bus Stop, Cannonvale",
        "images": [BUS_IMAGE, "/home/ubuntu/opsly/app/static/island.jpeg"],
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "reefgateway",
        "aliases": ["reefgateway", "reefgatewayhotel", "reef"],
        "address": "38 Shute Harbour Rd, Cannonvale",
        "images": [BUS_IMAGE, "/home/ubuntu/opsly/app/static/reef.jpeg"],
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "marinashores",
        "aliases": ["marinashores", "marina", "marinashore"],
        "address": "159 Shingley Dr, Cannonvale",
        "images": [BUS_IMAGE, "/home/ubuntu/opsly/app/static/marina.jpeg"],
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "reflections",
        "aliases": ["reflections"],
        "address": "25 Horizons Way, Airlie Beach",
        "images": [BUS_IMAGE],
        "picture_line": "Please see picture of your pickup vehicle attached.",
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "coralsearesort",
        "aliases": ["coralsearesort", "coralsea", "csr"],
        "address": "26 Ocean View Ave, Airlie Beach",
        "images": [BUS_IMAGE, "/home/ubuntu/opsly/app/static/csr.jpeg"],
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "mirage",
        "aliases": ["mirage"],
        "address": "38 Altmann Ave, Cannonvale",
        "images": [BUS_IMAGE, "/home/ubuntu/opsly/app/static/mirage.jpeg"],
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "domestic",
        "aliases": ["domestic", "domesticterminal", "airport", "whitsundaycoastairport"],
        "address": "Whitsunday Coast Airport",
        "images": [BUS_IMAGE, "/home/ubuntu/opsly/app/static/domestic.jpeg"],
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "base",
        "aliases": ["base", "nomads", "basenomads", "nomadbase"],
        "address": "336 Shute Harbour Rd, Airlie Beach",
        "images": [BUS_IMAGE, "/home/ubuntu/opsly/app/static/base.jpeg"],
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    },
    {
        "key": "mow",
        "aliases": ["mow", "lagunaquays", "lagoonaquays", "lq"],
        "address": "SKYONE Laguna Quays Airport, 253 Kunapipi Rd, Laguna Quays QLD 4800",
        "images": ["/home/ubuntu/opsly/app/static/lqwait.jpeg", "/home/ubuntu/opsly/app/static/lqpark.jpeg", "/home/ubuntu/opsly/app/static/lqenter.jpeg"],
        "meeting": True,
        "important": "IMPORTANT!!! - Please be waiting at your meeting location 5 minutes prior to the above mentioned time, the aircraft is unable to wait past your nominated meeting time. The aircraft may occasionally be late, you will be notified of delays longer than 10 minutes.",
        "picture_line": "Please see picture of your meeting location attached.",
        "extra_line": "Alternatively if you would like a courtesy pickup in Airlie Beach or Cannonvale please let us know.",
    },
]


def resolve_pickup_config(order):
    pickup_text = _slug(_pickup_label(order))
    for config in PICKUPS:
        for alias in config.get("aliases", []):
            if alias and _slug(alias) and _slug(alias) in pickup_text:
                return config
    return {
        "key": "generic",
        "aliases": [],
        "address": _value(order, "pickup_address", "pickup_location", default="Pickup location to be confirmed"),
        "images": [BUS_IMAGE],
        "important": "IMPORTANT!!! - Please be waiting at your pickup location 5 minutes prior to the above mentioned time, the bus is unable to wait past your nominated pickup time. The bus may occasionally be late, you will be notified of delays longer than 10 minutes.",
    }


def build_pickup_email(order):
    config = resolve_pickup_config(order)
    attachments = [path for path in config.get("images", []) if Path(path).exists()]
    return {
        "subject": SUBJECT,
        "body": _build_body(order, config),
        "attachments": attachments,
        "pickup_key": config.get("key", "generic"),
    }
